import sqlparse, glob
import sys, re

index = 0
p_indx = []
comp_indx = []

def get_Metadata(path):
    names = {}
    try:
        m_file = open(path, 'r')
    except FileNotFoundError:
        print("Metadata file does not exist")
        exit(0)
    m_data = m_file.read().splitlines()
    attr = []
    i = 0
    while i < len(m_data):
        if m_data[i] == "<begin_table>":
            tbl = m_data[i + 1]
            i = i + 2
            continue
        elif m_data[i] == "<end_table>":
            names[tbl] = attr
            attr = []
        else:
            attr.append(m_data[i])
        i += 1
    return names

def Store_Data(files, Table_Names):
    tdata = {}
    for i in range(len(files)):
        data = open(files[i], 'r')
        val = data.read().splitlines()
        values = []
        name = files[i].replace(".csv", "").split("/")[-1]
        attr = Table_Names[name] # attibutes list of csv file
        values.append(attr)
        for item in val:
            item = re.sub(r"\s+", " ", item.replace("\"", " ").replace(
                "\'", " ").replace(",", " ")).split(" ")
            if len(item) != len(Table_Names[name]):
                print("File data doesn't match metadata")
                exit(0)
            values.append(item)
        # print(values)
        tdata[name] = values
    return tdata

def get_TableNames(files):
    Table_csv = {}
    for i in range(len(files)):
        Table_csv[files[i].replace(".csv", "").split("/")[-1]] = i
    return Table_csv

def check_ForValidity(tokens):
    global index
    if str(tokens[2].ttype) == "Token.Keyword" and str(tokens[2]).lower() == "distinct":
        index = 2
    ind = index
    if str(tokens[0]).lower() != "select":
        return False
    if tokens[ind+2].ttype == None and len(str(tokens[ind+2]).split(",")) > 0:
        pass
    elif str(tokens[ind+2].ttype) == "Token.Wildcard":
        pass
    else:
        return False
    if str(tokens[ind+4]).lower() != "from":
        return False
    if (tokens[ind+6].ttype == None and len(str(tokens[ind+6]).split(",")) > 0 and 
            str(tokens[ind+6]).split(" ")[0].lower() != "where"):
        pass
    else:
        return False
    if len(tokens) > (10+ind):
        if (tokens[10 + ind].ttype == None and 
            len(re.sub(r"\s+", " ", str(tokens[10 + ind])).split(" ")) > 1 and 
            str(tokens[ind + 10]).split(" ")[0].lower() == "where"):
            pass
        else:
            return False
    return True

def Combine_Two(table1, table2, table1_data, table2_data):
    combined = [] # major logic change done but minor code change - in total function
    if table1 != "mixed":
        row1 = [table1 + "." + item for item in table1_data[0]]
    else:
        row1 = table1_data[0]
    if table2 != "mixed":
        row2 = [table2 + "." + item for item in table2_data[0]]
    else:
        row2 = table2_data[0]
    row1.extend(row2)
    combined.append(row1)
    for i in range(1, len(table1_data)):
        row_list = table1_data[i][:]
        for j in range(1,len(table2_data)):
            new_row = table2_data[j][:]
            row_list.extend(new_row)
            combined.append(row_list)
            row_list = table1_data[i][:]
    return combined

def get_Joins(table_List, table_data, Table_Names):
    if len(table_List) == 1:
        rows = []
        rows.append(
            [table_List[0] + "." + item for item in table_data[table_List[0]][0]])
        rows.extend(table_data[table_List[0]][1:])
        return rows
    else:
        used = [table_List[0]]
        if table_List[1] not in used:
            row = Combine_Two(table_List[0], table_List[1], table_data[table_List[0]], table_data[table_List[1]]) #changed - added two extra args
            used.append(table_List[1])
        else:
            print("Not a unique table alias: " + table_List[1])
            exit(0)
        for i in range(2,len(table_List)):
            if table_List[i] not in used:
                row = Combine_Two("mixed", table_List[i], row, table_data[table_List[i]]) # changed -- added two extra args
                used.append(table_List[i])
            else:
                print("Not a unique table alias: " + table_List[i])
                exit(0)
        return row

def get_FullArgs(arg, tables, table_List):
    if len(re.sub(r"\s+", " ", arg.replace(".", " ")).split(" ")) > 1:
        return arg
    else:
        for key in table_List:
            if arg in tables[key][0]:
                val = key + "." + arg
                return val

def get_Aggregate(arg, ind, data):
    if len(data) == 1:
        return "NULL"
    if arg.lower() == "sum":
        val = 0
        for lists in data[1:]:
            val += float(lists[ind])
    elif arg.lower() == "max":
        val = float(data[1][ind])
        for lists in data[1:]:
            if float(lists[ind]) > val:
                val =  float(lists[ind])
    elif arg.lower() == "min":
        val = float(data[1][ind])
        for lists in data[1:]:
            if float(lists[ind]) < val:
                val = float(lists[ind])
    elif arg.lower() == "avg":
        val = get_Aggregate("sum", ind, data)
        n = len(data[1:])
        val = val/n
    else:
        print("Unknown aggregate")
        exit(0)
    return val

def get_ArgsDdata(arg_List, Tables_Data, table_List, data):
    keywords = []
    ind = []
    for arg in arg_List:
        arg = re.sub(r"\s+", " ", arg.replace(
            "(", " ").replace(")", " ")).split(" ")
        keywords.append(arg[0])
        if len(arg) == 1:
            inds = 0
        else:
            inds = 1
        full_arg = get_FullArgs(arg[inds], Tables_Data, table_List)
        ind.append(data[0].index(full_arg))
    return keywords, ind

def convert_LolSet(data):
    req_data = set()
    for lists in data:
        req_data.add(tuple(lists))
    return req_data

def convert_SetLol(data):
    req_data = []
    for tupple in data:
        req_data.append(list(tupple))
    return req_data

def get_Distinct(data):
    req_data = convert_LolSet(data)
    required = convert_SetLol(req_data)
    return required

def get_AllData(table_List, Tables_Data, arg_List, Table_Names, data):
    if not data:
        row_data = get_Joins(table_List, Tables_Data, Table_Names)
    else:
        row_data = data[:]
    req_data = []
    if len(arg_List) == 1 and arg_List[0] == '*':
        if index == 0:
            return row_data
        else:
            req_data.append(row_data[0])
            req_data.extend(get_Distinct(row_data[1:]))
            return req_data
    else:
        temp_data = []
        if len(re.sub(r"s\+", "", arg_List[0].replace("(", " ").replace(")", " ")).split(" ")) == 1:
            ind = get_ArgsDdata(arg_List, Tables_Data, table_List, row_data)[1]
            row = []
            for lists in row_data:
                for i in ind:
                    row.append(lists[i])
                temp_data.append(row)
                row = []
            rows = temp_data[0]
            if index != 0:
                req_data.append(rows)
                req_data.extend(get_Distinct(temp_data[1:]))
            else:
                req_data = temp_data
            return req_data
        else:
            keywords, ind = get_ArgsDdata(
                arg_List, Tables_Data, table_List, row_data)
            final_keywords = []
            final_values = []
            for i in range(len(keywords)):
                val = str(get_Aggregate(keywords[i], ind[i], row_data))
                final_keywords.append(
                    keywords[i] + "(" + row_data[0][ind[i]] + ")")
                final_values.append(val)
            req_data.append(final_keywords)
            if index != 0:
                final_values = get_Distinct([final_values])
                req_data.extend(final_values)
            else:
                req_data.append(final_values)
            return req_data


def get_Where(table_List, Tables_Data, args, row_data, atrb):
    global p_indx
    req_data = []
    req_data.append(row_data[0])
    if args[0].lstrip('+-').isdigit() == False and args[2].lstrip('+-').isdigit() == False:
        check_Arguments([args[0], args[2]], atrb)
        ind = get_ArgsDdata([args[0], args[2]], Tables_Data,
                           table_List, row_data)[1]
        string = "float(lists[" + str(ind[0]) + "]) " + args[1] + " float(lists[" + str(ind[1]) + "])"
        if ind[0] != ind[1] and args[1] == "==":
            if ind[1] not in p_indx:
                p_indx.append(ind[1])
                comp_indx.append(ind[0])
            elif ind[0] not in p_indx and ind[0] not in comp_indx:
                p_indx.append(ind[0])

    else:
        check_Arguments([args[0]], atrb)
        ind = get_ArgsDdata([args[0]], Tables_Data, table_List, row_data)[1]
        string = "float(lists[" + str(ind[0]) + "]) " + args[1] + " " + args[2]
    for lists in row_data[1:]:
        if eval(string):
            req_data.append(lists)
    return req_data

def get_DataWhere(table_List, Tables_Data, arg_List, Table_Names, query, atrb):
    row_data = get_Joins(table_List, Tables_Data, Table_Names)
    data = get_Where(table_List, Tables_Data, query[:3], row_data, atrb)
    i = 3
    while i < len(query)-2:
        if query[i].lower() == "and":
            data = get_Where(table_List, Tables_Data,
                              query[i + 1:i + 4], data, atrb)
        elif query[i].lower() == "or":
            new_data = get_Where(table_List, Tables_Data,
                                 query[i + 1:i + 4], row_data, atrb)
            top = new_data[0]
            temp = []
            temp.append(top)
            temp.extend(convert_SetLol(set().union(
                convert_LolSet(new_data[1:]), convert_LolSet(data[1:]))))
            data = temp[:]
        else:
            print("Invalid keyword: " + query[i] + ". Check SQL syntax.")
            exit(0)
        i += 4
    data = get_AllData(table_List, Tables_Data, arg_List, Table_Names, data)
    return data

def check_Table(table_List,Table_csv):
    tables = Table_csv.keys()
    for table in table_List:
        if table not in tables:
            print("Table doesn't exist")
            exit(0)
    return

def check_Arguments(argmnt_list, attrib):
    t = 0
    p = 0
    for argmnt in argmnt_list:
        fl = 0
        argmnt = re.sub(r"\s+", " ", argmnt.replace(
            "(", " ").replace(")", " ")).split(" ")
        if len(argmnt) == 1:
            val = argmnt[0]
            p = 1
        else:
            val = argmnt[1]
            t = 1
        if t == 1 and p == 1:
            print("Non-aggregated column and aggregated column given together")
            exit(0)
        for box in attrib:
            if val in box:
                fl += 1
        if fl == 0:
            print("Unknown column in field list")
            exit(0)
        elif fl > 1:
            print("Column is ambiguous")
            exit(0)
    return

def print_Table(table):
    global p_indx
    if not table or len(table) < 2:
        print("Empty set")
        return
    i = 0
    giv_lst = []
    p_indx.sort()
    for lists in table:
        for ind in p_indx:
            giv_lst += lists[i:ind]
            i = ind + 1
        # print(giv_lst,lists[i:-1])
        giv_lst += lists[i:]
        # print(lists)
        string = ", ".join(giv_lst)
        giv_lst = []
        i = 0
        print(string)
    return

def get_Attributes(table,table_List):
    attr = []
    for key in table_List:
        attr.append(table[key])
        attr.append([key + "." + item for item in table[key]])
    return attr

def main():
    # dir_path = "files/"
    dir_path = ""
    Table_Names = get_Metadata(dir_path + 'metadata.txt') # {} -> table names with attributes
    # print(Table_Names)

    files = glob.glob(dir_path + "*.csv") # list of csv files paths
    if not files:
        print("No csv files in the directory")
        exit(0)
    
    Table_csv = get_TableNames(files) # {} -> table names with table number
    # print(Table_csv)

    Tables_Data = Store_Data(files, Table_Names) 
    # print(Tables_Data)

    try:
        arg = sys.argv[1]
    except IndexError:
        print("No query given. Format is - python3 sql_engine.py 'query'")
        exit(0)
    arg = re.sub(r"\s+", " ", arg)
    query = sqlparse.parse(arg)
    qtoks = query[0].tokens
    # print([t.ttype for t in qtoks])
    
    query_2 = str(qtoks[-1]).replace("<=", " lt!eq ").replace(">=", " gt!eq ").replace(";","")
    query_2 = re.sub(r'\s+', ' ', query_2.replace(">", " > ").replace("<", " < ").replace(
        "=", " == ").replace("gt!eq", ">=").replace("lt!eq", "<=")).split(" ")
    # print(qtoks)
    # print(len(qtoks))
    try:
        if check_ForValidity(qtoks) == False:
            print("Query is not valid")
            exit(0)
    except Exception as ex:
        print("Query is invalid")
        exit(0)    
    table_List = re.sub(r"\s+", " ", str(qtoks[6 + index]).replace(",", " ")).split(" ")
    check_Table(table_List, Table_csv)
    atrb = get_Attributes(Table_Names, table_List)
    atrb.append(["*"])
    arg_List = re.sub(r"\s+", " ", str(qtoks[2 + index]).replace(",", " ")).split(" ")
    check_Arguments(arg_List, atrb)
    # print(arg_List, table_List)
    punc = 0
    try:
        punc = [str(t.ttype) for t in qtoks].index("Token.Punctuation")
        # print(punc)
    except ValueError:
        # print(str(qtoks[-1]).split(";"))
        if len(qtoks) in [7 + index, 8 + index]:
            print("Semi-colon is missing")
            exit(0)
        elif qtoks[-1].ttype is None and len(str(qtoks[-1]).split(";")) > 1:
            pass
        else:
            print("Semi-colon is missing")
            exit(0)
    # try:
    if punc in [7 + index, 8 + index]:
        final_table = get_AllData(
            table_List, Tables_Data, arg_List, Table_Names, [])
        # print(final_table)
    else:
        final_table = get_DataWhere(table_List, Tables_Data, arg_List, Table_Names, query_2[1:], atrb)
    print_Table(final_table)
    # except Exception as ex:
        # print("Something went wrong. Recheck the query")

if __name__ == '__main__':
    main()
